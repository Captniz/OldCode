#include<stdio.h>

int main()
{
	int n,m,i=1,s=0,c=0,min=0;
	
	printf("inserire il primo numero: \n");
	scanf("%d",&n);
	fflush(stdin);
		
	printf("inserire il secondo numero: \n");
	scanf("%d",&m);
	fflush(stdin);
	
	min=n;
	if(m<n)
		min=m;
	
	while(i<=min)
	{
		if(n%i==0 && m%i==0)
		{
			printf("%d	",i);
			s=s+i;
			c=c+1;
		}
		i=i+1;
	}
	
	printf("conteggio = %d	",c);
	printf("somma = %d",s);
	
	return 0;
}
