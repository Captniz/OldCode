#include<stdio.h>

int main()
{
	int b,h,area;
	
	printf("i byte di un int sono: %d \n",sizeof(b));
	
	printf("altezza rettangolo: ");
	scanf("%d",&h); //si pu� usare %i
	fflush(stdin); //while((getchar())!='\n');
	printf("base rettangolo: ");
	scanf("%d",&b);
	fflush(stdin);
	
	area=b*h;
	
	printf("area del rettangolo = %d",area);
	
	return 0;
}
