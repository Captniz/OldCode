#include<stdio.h>

int main()
{
	int n,i=1,cp=0,cd=0;
	
	printf("inserisci un numero: ");
	scanf("%d",&n);
	fflush(stdin);
	
	while(i<=n)
	{
		if(n%i==0)
		{
			if(i%2==0)
			{
				printf("pari: %d\n",i);
				cp=cp+1;
			}else
			{
				printf("dispari: %d\n",i);
				cd=cd+1;
			}
		}	
		
		i=i+1;
	}
	
	printf("tot. pari = %d\n",cp);
	printf("tot. dispari = %d",cd);
	
	return 0;
}
