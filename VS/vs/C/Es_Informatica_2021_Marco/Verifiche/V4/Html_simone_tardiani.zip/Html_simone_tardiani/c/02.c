#include<stdio.h>

int main()
{
	int n,s=0,i=0;

	while(i!=10)
	{
		printf("inserire il numero: \n");
		scanf("%d",&n);
		fflush(stdin);
		
		i=i+1;
		s=s+n;
	}
	
	if(s>100)
	{
		printf("%d>100",s);
	}
	else
	{	
		if(s==100)
		{
			printf("%d=100",s);
		}else
		{
			printf("%d<100",s);
		}
	}
	return 0;
}
